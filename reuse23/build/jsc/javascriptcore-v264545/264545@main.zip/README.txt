Bundle details:
  - WebKit Platform: GTK
  - Configuration: Release
  - WebKit Revision: 264545@main
  - Bundle type: jsc
  - Builder name: GTK-Linux-64-bit-Release-Build
  - Builder date: 2023-05-25T20:30:21.451536
  - Builder OS: WebKit SDK 264517@main (Flatpak runtime)

Run instructions:
  - Execute the wrapper script in this directory:
    * jsc
